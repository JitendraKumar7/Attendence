import 'dart:ui';

final colorPrimaryDark = Color(0xff04549C);
final colorPrimary = Color(0xff42D0F9);
final colorBlack = Color(0xff3a3a3a);
