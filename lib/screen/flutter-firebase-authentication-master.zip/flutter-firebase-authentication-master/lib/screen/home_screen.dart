import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebase_auth/res/color.dart';
import 'package:flutter_firebase_auth/res/style.dart';
import 'package:flutter_firebase_auth/service/firebase/firebase_auth_service.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:location/location.dart';

class HomeScreen extends StatefulWidget {


  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return HomeState();
  }
}
class HomeState extends State<HomeScreen>{
  final picker = ImagePicker();
File _imageFile;
  Future pickImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.camera);

    setState(() {
      _imageFile = File(pickedFile.path);
      uploadImageToFirebase(context,_imageFile);
    });


  }
  FirebaseStorage _storage = FirebaseStorage.instance;

 /* Future<Uri> uploadPic() async {

    //Get the file from the image picker and store it
    File image = await ImagePicker.pickImage(source: ImageSource.gallery);

    //Create a reference to the location you want to upload to in firebase
    StorageReference reference = _storage.ref().child("images/");

    //Upload the file to firebase
    StorageUploadTask uploadTask = reference.putFile(image);

    // Waits till the file is uploaded then stores the download url
   // Uri location = (await uploadTask.future).downloadUrl;

    //returns the download url
    return location;
  }*/
  Future uploadImageToFirebase(BuildContext context,File imageFIle) async {

    StorageReference firebaseStorageRef =
    FirebaseStorage.instance.ref().child('uploads');
    StorageUploadTask uploadTask = firebaseStorageRef.putFile(imageFIle);
    StorageTaskSnapshot taskSnapshot = await uploadTask.onComplete;
    taskSnapshot.ref.getDownloadURL().then(
          (value) => print("Done: $value"),
    );
  }
  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);
  LatLng _initialcameraposition = LatLng(20.5937, 78.9629);
  GoogleMapController _controller;
  Location _location = Location();

  void _onMapCreated(GoogleMapController _cntlr)
  {
    _controller = _cntlr;
    _location.onLocationChanged.listen((l) {
      _controller.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(target: LatLng(l.latitude, l.longitude),zoom: 15),

        ),

      );
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.lock_open),
            onPressed: () => FirebaseAuthService.firebaseLogout(),
            tooltip: 'Logout',
          )
        ],
        title: Text(
          'Welcome',
          style: styleToolbar,
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            child: FutureBuilder(
                future: FirebaseAuthService.firebaseUserDetail(),
                builder: (BuildContext context,
                    AsyncSnapshot<FirebaseUser> firebaseSnapshot) {
                  if (firebaseSnapshot.hasData) {
                    return Text(
                      'Welcome ${firebaseSnapshot.data.email}',
                      style: styleButtonText.copyWith(color: colorBlack),
                    );
                  }
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }),
          ),
          Container(height: 250,
            child: GoogleMap(
              initialCameraPosition: CameraPosition(target: _initialcameraposition),

              mapType: MapType.normal,
              onMapCreated: _onMapCreated,
              myLocationEnabled: true,


            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: (){
        pickImage();

//uploadImageToFirebase(context);
      },
        child: Icon(Icons.camera_alt),),
    );
  }


}