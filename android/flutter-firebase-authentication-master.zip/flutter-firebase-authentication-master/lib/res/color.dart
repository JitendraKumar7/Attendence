import 'dart:ui';

final colorPrimaryDark = Color(0xff04549C);
final colorPrimary =  Color(0xff04549C);
final colorBlack = Color(0xff3a3a3a);
