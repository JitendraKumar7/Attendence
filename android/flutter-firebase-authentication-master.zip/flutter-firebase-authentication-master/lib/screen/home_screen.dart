import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebase_auth/res/color.dart';
import 'package:flutter_firebase_auth/res/style.dart';
import 'package:flutter_firebase_auth/service/firebase/firebase_auth_service.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatefulWidget {


  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return HomeState();
  }
}
class HomeState extends State<HomeScreen>{
  final picker = ImagePicker();
File _imageFile;
  Future pickImage(bool checkin,bool checkout) async {
    final pickedFile = await picker.getImage(source: ImageSource.camera, imageQuality: 50,);

    setState(() {
      _imageFile = File(pickedFile.path);
      uploadImageToFirebase(context,_imageFile,checkin,checkout);
    });


  }
  FirebaseStorage _storage = FirebaseStorage.instance;

 /* Future<Uri> uploadPic() async {

    //Get the file from the image picker and store it
    File image = await ImagePicker.pickImage(source: ImageSource.gallery);

    //Create a reference to the location you want to upload to in firebase
    StorageReference reference = _storage.ref().child("images/");

    //Upload the file to firebase
    StorageUploadTask uploadTask = reference.putFile(image);

    // Waits till the file is uploaded then stores the download url
   // Uri location = (await uploadTask.future).downloadUrl;

    //returns the download url
    return location;
  }*/
  Future uploadImageToFirebase(BuildContext context,File imageFIle,bool checkin,bool Checkout) async {

    Reference firebaseStorageRef = FirebaseStorage.instance.ref().child('uploads');
    UploadTask uploadTask = firebaseStorageRef.putFile(imageFIle);
    uploadTask.then((res) {
      res.ref.getDownloadURL().then((value) {
        setState(() {
          UploadDataFireStore(value,checkin,Checkout);
        });
      });

    });

  }
  Future<String> inputData() async {
    final User user = await FirebaseAuth.instance.currentUser;
    final String uid = user.uid.toString();
    return uid;
  }
UploadDataFireStore(String Imagedata,bool checkin,bool checkout) async {
  final User user = await FirebaseAuth.instance.currentUser;
  final String uid = user.uid.toString();
  DateTime now = DateTime.now().microsecondsSinceEpoch;
  String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);

  FirebaseFirestore.instance.collection('attendence').add({'address': 'data added through app','date':formattedDate,'image':Imagedata,'checkin':checkin,'lat':"13",'long':"uis",'checkout':checkout,'uid':uid});

}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.lock_open),
            onPressed: () => FirebaseAuthService.firebaseLogout(),
            tooltip: 'Logout',
          )
        ],
        title: Text(
          'Welcome',
          style: styleToolbar,
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        child: FutureBuilder(
            future: FirebaseAuthService.firebaseUserDetail(),
            builder: (BuildContext context, AsyncSnapshot<User> firebaseSnapshot) {
              if (firebaseSnapshot.hasData) {
                return Text(
                  'Welcome ${firebaseSnapshot.data.email}',
                  style: styleButtonText.copyWith(color: colorBlack),
                );
              }
              return Center(
                child: CircularProgressIndicator(),
              );
            }),
      ),
      floatingActionButton:FabCircularMenu(

          fabCloseColor: Colors.deepOrangeAccent,
          //Color of FAB when menu is not open
          fabOpenColor: Colors.amber,
          //color of FAB when menu is open

          fabOpenIcon: Icon(Icons.menu, color: Colors.white),
          //FAB icon when menu is not open
          fabCloseIcon: Icon(Icons.close, color: Colors.white),
          //FAB icon when menu is open

          ringColor: Color(0xff04549C),
          //set ring color to Colors.transparent for transparent ring

          children: <Widget>[
            //here you can add menu buttons
            // You should add atleast two menu button
            // otherwise it will show error.




            fabsinglemenu("Checkout", (){
              //set action for this menu
              pickImage(false,true);
            }),
            fabsinglemenu("CheckIn", (){
              //set action for this menu
              pickImage(true,false);
            }),


          ]
      ), //FAB circular Menu


    );
  }


}
Widget fabsinglemenu(String icon, Function onPressFunction){
  return  SizedBox(
      width:125, height:55,
      //height and width for menu button

      child: RaisedButton(
        color: Colors.white,
        child: Text(icon, style: styleSmallText.copyWith(color: Color(0xff04549C),),),
        onPressed: onPressFunction,
        shape: RoundedRectangleBorder(
          borderRadius: new BorderRadius.circular(60.0),
        ),
      )
  );
}
