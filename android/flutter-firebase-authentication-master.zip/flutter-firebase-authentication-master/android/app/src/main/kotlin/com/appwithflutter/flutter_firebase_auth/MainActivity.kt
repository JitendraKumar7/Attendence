package com.appwithflutter.flutter_firebase_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
